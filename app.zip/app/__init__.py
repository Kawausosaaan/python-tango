# app/__init__.py
from .main import main
from .main_panel import MainPanel
